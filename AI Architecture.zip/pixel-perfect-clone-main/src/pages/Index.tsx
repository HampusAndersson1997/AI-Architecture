import { useState } from "react";
import Sidebar from "@/components/layout/Sidebar";
import PortfolioHeader from "@/components/dashboard/PortfolioHeader";
import PerformanceChart from "@/components/dashboard/PerformanceChart";
import AllocationChart from "@/components/dashboard/AllocationChart";
import HoldingsTable from "@/components/dashboard/HoldingsTable";
import TickerAgent from "@/components/agents/TickerAgent";
import CountryAgent from "@/components/agents/CountryAgent";
import IndustryAgent from "@/components/agents/IndustryAgent";

const Index = () => {
  const [activeTab, setActiveTab] = useState("dashboard");

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <div className="space-y-6">
            <PortfolioHeader />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <PerformanceChart />
              <AllocationChart />
            </div>
          </div>
        );
      case "holdings":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Portföljinnehav</h2>
              <p className="text-muted-foreground">Detaljerad översikt av alla positioner</p>
            </div>
            <HoldingsTable />
          </div>
        );
      case "ticker-agent":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Ticker Agent</h2>
              <p className="text-muted-foreground">AI-analys av individuella aktier</p>
            </div>
            <div className="max-w-2xl">
              <TickerAgent />
            </div>
          </div>
        );
      case "country-agent":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Country Agent</h2>
              <p className="text-muted-foreground">AI-analys av geografisk exponering</p>
            </div>
            <div className="max-w-2xl">
              <CountryAgent />
            </div>
          </div>
        );
      case "industry-agent":
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Industry Agent</h2>
              <p className="text-muted-foreground">AI-analys av sektorexponering</p>
            </div>
            <div className="max-w-2xl">
              <IndustryAgent />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 p-8 overflow-auto">
        {renderContent()}
      </main>
    </div>
  );
};

export default Index;
