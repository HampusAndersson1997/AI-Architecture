import { LayoutDashboard, PieChart, Bot, BarChart3, Globe, Factory } from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar = ({ activeTab, setActiveTab }: SidebarProps) => {
  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "holdings", label: "Innehav", icon: PieChart },
    { id: "ticker-agent", label: "Ticker Agent", icon: BarChart3 },
    { id: "country-agent", label: "Country Agent", icon: Globe },
    { id: "industry-agent", label: "Industry Agent", icon: Factory },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border min-h-screen p-4">
      <div className="flex items-center gap-2 mb-8 px-2">
        <div className="p-2 bg-primary rounded-lg">
          <Bot className="h-6 w-6 text-primary-foreground" />
        </div>
        <div>
          <h1 className="font-bold text-foreground">PortfolioAI</h1>
          <p className="text-xs text-muted-foreground">Research Platform</p>
        </div>
      </div>

      <nav className="space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="absolute bottom-4 left-4 right-4">
        <div className="bg-muted rounded-lg p-3">
          <p className="text-xs text-muted-foreground mb-1">Demo Version</p>
          <p className="text-xs text-foreground">Alla data är hårdkodad</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
