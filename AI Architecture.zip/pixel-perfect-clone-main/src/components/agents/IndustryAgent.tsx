import { useState } from "react";
import { Factory } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import AgentCard from "./AgentCard";
import { mockIndustryAnalysis } from "@/lib/mockData";

const IndustryAgent = () => {
  const [selectedIndustry, setSelectedIndustry] = useState<string>("Technology");

  const analysis = mockIndustryAnalysis[selectedIndustry as keyof typeof mockIndustryAnalysis];

  return (
    <div className="space-y-4">
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Factory className="h-5 w-5 text-primary" />
            Industry Agent
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Välj bransch" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Technology">Technology (37.5%)</SelectItem>
              <SelectItem value="Semiconductors">Semiconductors (16%)</SelectItem>
              <SelectItem value="Healthcare">Healthcare (14.5%)</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {analysis && (
        <>
          <AgentCard
            title={`${selectedIndustry} Analys`}
            subject={`Sektorexponering`}
            sentiment={analysis.sentiment}
            score={analysis.score}
            analysis={analysis.analysis}
            icon={<Factory className="h-5 w-5 text-primary" />}
          />

          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-foreground">Branschöversikt</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Utsikter</p>
                <p className="text-sm text-foreground">{analysis.outlook}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-2">Top Picks</p>
                <div className="flex gap-2">
                  {analysis.topPicks.map((pick, index) => (
                    <Badge key={index} className="bg-primary/10 text-primary border-primary/20">
                      {pick}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};

export default IndustryAgent;
