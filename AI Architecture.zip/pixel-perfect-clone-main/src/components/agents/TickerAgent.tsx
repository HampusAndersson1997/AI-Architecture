import { useState } from "react";
import { BarChart3 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import AgentCard from "./AgentCard";
import { mockTickerAnalysis, mockHoldings } from "@/lib/mockData";

const TickerAgent = () => {
  const [selectedTicker, setSelectedTicker] = useState<string>("AAPL");

  const analysis = mockTickerAnalysis[selectedTicker as keyof typeof mockTickerAnalysis];

  if (!analysis) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <BarChart3 className="h-5 w-5 text-primary" />
            Ticker Agent
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedTicker} onValueChange={setSelectedTicker}>
            <SelectTrigger className="w-full mb-4">
              <SelectValue placeholder="Välj aktie" />
            </SelectTrigger>
            <SelectContent>
              {mockHoldings.filter(h => h.ticker !== "CASH").map((holding) => (
                <SelectItem key={holding.ticker} value={holding.ticker}>
                  {holding.ticker} - {holding.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-muted-foreground text-center py-8">
            Ingen analys tillgänglig för {selectedTicker}. 
            <br />
            <span className="text-sm">Välj AAPL, MSFT eller NVDA för demo.</span>
          </p>
        </CardContent>
      </Card>
    );
  }

  const holding = mockHoldings.find(h => h.ticker === selectedTicker);

  return (
    <div className="space-y-4">
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <BarChart3 className="h-5 w-5 text-primary" />
            Ticker Agent
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedTicker} onValueChange={setSelectedTicker}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Välj aktie" />
            </SelectTrigger>
            <SelectContent>
              {mockHoldings.filter(h => h.ticker !== "CASH").map((holding) => (
                <SelectItem key={holding.ticker} value={holding.ticker}>
                  {holding.ticker} - {holding.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <AgentCard
        title={`${selectedTicker} Analys`}
        subject={holding?.name || selectedTicker}
        sentiment={analysis.sentiment}
        score={analysis.score}
        analysis={analysis.analysis}
        icon={<BarChart3 className="h-5 w-5 text-primary" />}
      />

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-sm text-foreground">Nyckeltal</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-foreground">{analysis.keyMetrics.pe}</p>
              <p className="text-xs text-muted-foreground">P/E Ratio</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-500">+{analysis.keyMetrics.revenueGrowth}%</p>
              <p className="text-xs text-muted-foreground">Omsättningstillväxt</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-foreground">{analysis.keyMetrics.profitMargin}%</p>
              <p className="text-xs text-muted-foreground">Vinstmarginal</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TickerAgent;
