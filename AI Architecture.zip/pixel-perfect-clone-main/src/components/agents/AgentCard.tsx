import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

interface AgentCardProps {
  title: string;
  subject: string;
  sentiment: "bullish" | "bearish" | "neutral";
  score: number;
  analysis: string;
  icon: React.ReactNode;
}

const AgentCard = ({ title, subject, sentiment, score, analysis, icon }: AgentCardProps) => {
  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "bullish":
        return "bg-green-500/10 text-green-500 border-green-500/20";
      case "bearish":
        return "bg-red-500/10 text-red-500 border-red-500/20";
      default:
        return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case "bullish":
        return <TrendingUp className="h-4 w-4" />;
      case "bearish":
        return <TrendingDown className="h-4 w-4" />;
      default:
        return <Minus className="h-4 w-4" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 75) return "bg-green-500";
    if (score >= 50) return "bg-yellow-500";
    return "bg-red-500";
  };

  return (
    <Card className="bg-card border-border hover:border-primary/50 transition-colors">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              {icon}
            </div>
            <div>
              <CardTitle className="text-lg text-foreground">{title}</CardTitle>
              <p className="text-sm text-muted-foreground">{subject}</p>
            </div>
          </div>
          <Badge className={getSentimentColor(sentiment)}>
            <span className="flex items-center gap-1">
              {getSentimentIcon(sentiment)}
              {sentiment.charAt(0).toUpperCase() + sentiment.slice(1)}
            </span>
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Confidence Score</span>
            <span className="font-semibold text-foreground">{score}/100</span>
          </div>
          <Progress value={score} className={`h-2 ${getScoreColor(score)}`} />
        </div>
        
        <p className="text-sm text-muted-foreground leading-relaxed">
          {analysis}
        </p>
      </CardContent>
    </Card>
  );
};

export default AgentCard;
