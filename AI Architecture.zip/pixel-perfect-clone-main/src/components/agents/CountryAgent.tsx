import { useState } from "react";
import { Globe } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import AgentCard from "./AgentCard";
import { mockCountryAnalysis } from "@/lib/mockData";

const CountryAgent = () => {
  const [selectedRegion, setSelectedRegion] = useState<string>("USA");

  const analysis = mockCountryAnalysis[selectedRegion as keyof typeof mockCountryAnalysis];

  return (
    <div className="space-y-4">
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Globe className="h-5 w-5 text-primary" />
            Country Agent
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedRegion} onValueChange={setSelectedRegion}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Välj region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="USA">USA (51%)</SelectItem>
              <SelectItem value="Europe">Europa (22%)</SelectItem>
              <SelectItem value="Asia">Asien (7.5%)</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {analysis && (
        <>
          <AgentCard
            title={`${selectedRegion} Analys`}
            subject={`Regional exponering: ${selectedRegion === "USA" ? "51%" : selectedRegion === "Europe" ? "22%" : "7.5%"}`}
            sentiment={analysis.sentiment}
            score={analysis.score}
            analysis={analysis.analysis}
            icon={<Globe className="h-5 w-5 text-primary" />}
          />

          <div className="grid grid-cols-2 gap-4">
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-red-500">Risker</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {analysis.risks.map((risk, index) => (
                    <Badge key={index} variant="outline" className="text-red-500 border-red-500/30">
                      {risk}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-green-500">Möjligheter</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {analysis.opportunities.map((opportunity, index) => (
                    <Badge key={index} variant="outline" className="text-green-500 border-green-500/30">
                      {opportunity}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
};

export default CountryAgent;
