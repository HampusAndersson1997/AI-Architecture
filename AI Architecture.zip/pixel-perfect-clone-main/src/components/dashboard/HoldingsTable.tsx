import { TrendingUp, TrendingDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { mockHoldings } from "@/lib/mockData";

const HoldingsTable = () => {
  const calculateReturn = (purchase: number, current: number) => {
    return ((current - purchase) / purchase) * 100;
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-foreground">Innehav</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="text-muted-foreground">Ticker</TableHead>
                <TableHead className="text-muted-foreground">Namn</TableHead>
                <TableHead className="text-muted-foreground">Land</TableHead>
                <TableHead className="text-muted-foreground">Bransch</TableHead>
                <TableHead className="text-muted-foreground text-right">Allokering</TableHead>
                <TableHead className="text-muted-foreground text-right">Pris</TableHead>
                <TableHead className="text-muted-foreground text-right">Avkastning</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockHoldings.map((holding) => {
                const returnPct = calculateReturn(holding.purchase_price, holding.current_price);
                const isPositive = returnPct >= 0;

                return (
                  <TableRow key={holding.id} className="border-border hover:bg-muted/50">
                    <TableCell className="font-mono font-semibold text-foreground">
                      {holding.ticker}
                    </TableCell>
                    <TableCell className="text-foreground">{holding.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {holding.country}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{holding.industry}</TableCell>
                    <TableCell className="text-right font-medium text-foreground">
                      {holding.allocation_percent}%
                    </TableCell>
                    <TableCell className="text-right text-foreground">
                      ${holding.current_price.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className={`flex items-center justify-end gap-1 ${isPositive ? "text-green-500" : "text-red-500"}`}>
                        {isPositive ? (
                          <TrendingUp className="h-4 w-4" />
                        ) : (
                          <TrendingDown className="h-4 w-4" />
                        )}
                        <span className="font-medium">
                          {isPositive ? "+" : ""}{returnPct.toFixed(1)}%
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default HoldingsTable;
