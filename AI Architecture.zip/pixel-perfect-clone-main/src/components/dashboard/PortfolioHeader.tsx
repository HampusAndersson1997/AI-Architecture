import { TrendingUp, TrendingDown, DollarSign, Percent } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { mockPortfolio } from "@/lib/mockData";

const PortfolioHeader = () => {
  const isPositive = mockPortfolio.dailyChange >= 0;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-3xl font-bold text-foreground">{mockPortfolio.name}</h1>
        <p className="text-muted-foreground">{mockPortfolio.description}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Totalt Värde</p>
                <p className="text-2xl font-bold text-foreground">
                  {mockPortfolio.totalValue.toLocaleString("sv-SE")} SEK
                </p>
              </div>
              <div className="p-3 bg-primary/10 rounded-full">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Daglig Förändring</p>
                <p className={`text-2xl font-bold ${isPositive ? "text-green-500" : "text-red-500"}`}>
                  {isPositive ? "+" : ""}{mockPortfolio.dailyChange}%
                </p>
              </div>
              <div className={`p-3 rounded-full ${isPositive ? "bg-green-500/10" : "bg-red-500/10"}`}>
                {isPositive ? (
                  <TrendingUp className="h-6 w-6 text-green-500" />
                ) : (
                  <TrendingDown className="h-6 w-6 text-red-500" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Avkastning (YTD)</p>
                <p className="text-2xl font-bold text-green-500">
                  +{mockPortfolio.totalReturn}%
                </p>
              </div>
              <div className="p-3 bg-green-500/10 rounded-full">
                <Percent className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PortfolioHeader;
