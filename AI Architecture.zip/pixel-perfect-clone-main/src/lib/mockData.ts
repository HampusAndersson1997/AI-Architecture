// Hårdkodad data för portfolio-plattformen

export const mockPortfolio = {
  id: "1",
  name: "Global Growth Portfolio",
  description: "Diversifierad portfölj med fokus på tillväxtmarknader",
  totalValue: 1250000,
  dailyChange: 1.24,
  totalReturn: 18.5,
};

export const mockHoldings = [
  {
    id: "1",
    ticker: "AAPL",
    name: "Apple Inc.",
    country: "USA",
    industry: "Technology",
    allocation_percent: 15.5,
    shares: 150,
    purchase_price: 145.00,
    current_price: 178.50,
  },
  {
    id: "2",
    ticker: "MSFT",
    name: "Microsoft Corporation",
    country: "USA",
    industry: "Technology",
    allocation_percent: 12.0,
    shares: 80,
    purchase_price: 280.00,
    current_price: 378.00,
  },
  {
    id: "3",
    ticker: "NVDA",
    name: "NVIDIA Corporation",
    country: "USA",
    industry: "Technology",
    allocation_percent: 10.0,
    shares: 25,
    purchase_price: 450.00,
    current_price: 875.00,
  },
  {
    id: "4",
    ticker: "ASML",
    name: "ASML Holding",
    country: "Netherlands",
    industry: "Semiconductors",
    allocation_percent: 8.5,
    shares: 12,
    purchase_price: 580.00,
    current_price: 920.00,
  },
  {
    id: "5",
    ticker: "TSM",
    name: "Taiwan Semiconductor",
    country: "Taiwan",
    industry: "Semiconductors",
    allocation_percent: 7.5,
    shares: 60,
    purchase_price: 85.00,
    current_price: 142.00,
  },
  {
    id: "6",
    ticker: "NOVO-B",
    name: "Novo Nordisk",
    country: "Denmark",
    industry: "Healthcare",
    allocation_percent: 9.0,
    shares: 45,
    purchase_price: 95.00,
    current_price: 128.00,
  },
  {
    id: "7",
    ticker: "SAP",
    name: "SAP SE",
    country: "Germany",
    industry: "Enterprise Software",
    allocation_percent: 6.5,
    shares: 35,
    purchase_price: 125.00,
    current_price: 185.00,
  },
  {
    id: "8",
    ticker: "V",
    name: "Visa Inc.",
    country: "USA",
    industry: "Financial Services",
    allocation_percent: 8.0,
    shares: 40,
    purchase_price: 220.00,
    current_price: 275.00,
  },
  {
    id: "9",
    ticker: "JNJ",
    name: "Johnson & Johnson",
    country: "USA",
    industry: "Healthcare",
    allocation_percent: 5.5,
    shares: 35,
    purchase_price: 165.00,
    current_price: 158.00,
  },
  {
    id: "10",
    ticker: "LVMH",
    name: "LVMH Moët Hennessy",
    country: "France",
    industry: "Luxury Goods",
    allocation_percent: 7.0,
    shares: 8,
    purchase_price: 750.00,
    current_price: 890.00,
  },
  {
    id: "11",
    ticker: "CASH",
    name: "Cash & Equivalents",
    country: "Global",
    industry: "Cash",
    allocation_percent: 10.5,
    shares: 0,
    purchase_price: 1.00,
    current_price: 1.00,
  },
];

// Generera 12 månaders performance-data
export const mockPerformanceData = [
  { date: "Jan", value: 1000000, benchmark: 1000000 },
  { date: "Feb", value: 1025000, benchmark: 1015000 },
  { date: "Mar", value: 1010000, benchmark: 995000 },
  { date: "Apr", value: 1075000, benchmark: 1045000 },
  { date: "May", value: 1095000, benchmark: 1060000 },
  { date: "Jun", value: 1120000, benchmark: 1085000 },
  { date: "Jul", value: 1085000, benchmark: 1070000 },
  { date: "Aug", value: 1145000, benchmark: 1095000 },
  { date: "Sep", value: 1180000, benchmark: 1125000 },
  { date: "Oct", value: 1165000, benchmark: 1105000 },
  { date: "Nov", value: 1210000, benchmark: 1145000 },
  { date: "Dec", value: 1250000, benchmark: 1175000 },
];

// Aggregerad data för allocation-pie
export const mockAllocationByCountry = [
  { name: "USA", value: 51.0, color: "#3B82F6" },
  { name: "Netherlands", value: 8.5, color: "#F97316" },
  { name: "Taiwan", value: 7.5, color: "#10B981" },
  { name: "Denmark", value: 9.0, color: "#EF4444" },
  { name: "Germany", value: 6.5, color: "#8B5CF6" },
  { name: "France", value: 7.0, color: "#EC4899" },
  { name: "Global", value: 10.5, color: "#6B7280" },
];

export const mockAllocationByIndustry = [
  { name: "Technology", value: 37.5, color: "#3B82F6" },
  { name: "Semiconductors", value: 16.0, color: "#10B981" },
  { name: "Healthcare", value: 14.5, color: "#EF4444" },
  { name: "Financial Services", value: 8.0, color: "#F97316" },
  { name: "Luxury Goods", value: 7.0, color: "#EC4899" },
  { name: "Enterprise Software", value: 6.5, color: "#8B5CF6" },
  { name: "Cash", value: 10.5, color: "#6B7280" },
];

// AI Agent analyser (hårdkodade)
export const mockTickerAnalysis = {
  AAPL: {
    sentiment: "bullish" as const,
    score: 78,
    analysis: "Apple visar stark momentum med Services-segmentet som växer 15% YoY. iPhone 15-serien överträffar förväntningar i Kina. Vision Pro lansering öppnar ny produktkategori. Risker inkluderar regulatoriska utmaningar i EU och beroendet av Kina för produktion.",
    keyMetrics: {
      pe: 28.5,
      revenueGrowth: 8.2,
      profitMargin: 25.3,
    },
  },
  MSFT: {
    sentiment: "bullish" as const,
    score: 85,
    analysis: "Microsoft fortsätter dominera inom cloud med Azure-tillväxt på 29%. AI-integrering via Copilot skapar nya intäktsströmmar. LinkedIn och Gaming-segmenten presterar starkt. Stabil utdelning och buybacks stödjer aktien.",
    keyMetrics: {
      pe: 35.2,
      revenueGrowth: 12.5,
      profitMargin: 36.7,
    },
  },
  NVDA: {
    sentiment: "bullish" as const,
    score: 92,
    analysis: "NVIDIA är den obestridda ledaren inom AI-chips. Datacenter-intäkter växer explosivt (+200% YoY). H100-chipsen har fleråriga orderböcker. Risker inkluderar hög värdering och potentiell konkurrens från AMD och egenutvecklade chips.",
    keyMetrics: {
      pe: 65.4,
      revenueGrowth: 122.0,
      profitMargin: 55.8,
    },
  },
};

export const mockCountryAnalysis = {
  USA: {
    sentiment: "neutral" as const,
    score: 72,
    analysis: "USA utgör 51% av portföljen. Stark exponering mot tech-sektorn ger hög tillväxtpotential men också koncentrationsrisk. Fed:s räntepolicy förblir osäker. Arbetsmarknaden är robust men inflation är fortfarande sticky.",
    risks: ["Höga värderingar", "Ränterisk", "Tech-koncentration"],
    opportunities: ["AI-boom", "Stark konsumtion", "Innovation"],
  },
  Europe: {
    sentiment: "bullish" as const,
    score: 68,
    analysis: "Europeiska innehav (22% av portföljen) ger diversifiering. ASML, Novo Nordisk, SAP och LVMH är alla marknadsledare. Valutor kan ge volatilitet men fundamenta är starka. ECB håller räntor höga.",
    risks: ["Valutarisk EUR/SEK", "Geopolitik", "Energipriser"],
    opportunities: ["Underviktad marknad", "Starka varumärken", "GLP-1 boom"],
  },
  Asia: {
    sentiment: "neutral" as const,
    score: 65,
    analysis: "Taiwan Semiconductor representerar Asien-exponering. Geopolitiska risker kring Taiwan är reella men TSM har irreplaceable technology. Diversifiering mot Japan eller Indien kan övervägas.",
    risks: ["Taiwan-scenario", "Kina-beroende", "Dollarkurser"],
    opportunities: ["Chip-efterfrågan", "Tech-diversifiering"],
  },
};

export const mockIndustryAnalysis = {
  Technology: {
    sentiment: "bullish" as const,
    score: 82,
    analysis: "Tech utgör 37.5% av portföljen. AI-trenden driver tillväxt för AAPL, MSFT och NVDA. Risken är hög värdering och regulatoriska hot. Rekommendation: behåll men balansera med defensiva sektorer.",
    outlook: "Stark kortsiktig, osäker långsiktig p.g.a. värderingar",
    topPicks: ["NVDA", "MSFT"],
  },
  Semiconductors: {
    sentiment: "bullish" as const,
    score: 88,
    analysis: "Halvledare (16%) är portföljens starkaste sektor. ASML och TSM har monopol-liknande positioner. AI-efterfrågan driver flerårig supercykel. ASML:s EUV-maskiner har ingen konkurrens.",
    outlook: "Mycket stark, strukturell medvind från AI",
    topPicks: ["ASML", "TSM"],
  },
  Healthcare: {
    sentiment: "bullish" as const,
    score: 75,
    analysis: "Healthcare (14.5%) ger defensiv ballast. Novo Nordisk dominerar GLP-1 marknaden. JNJ ger stabilitet trots litigation-risker. Sektorn är undervärderad relativt tillväxtpotentialen.",
    outlook: "Stabil med Novo som tillväxtmotor",
    topPicks: ["NOVO-B"],
  },
};
